function Header({
    /* 수정하여 쓰는 부분 */
  logo = "Maison Bakery",
  menus = [
    { title: "Home", link: "#home" },
    { title: "About", link: "#about" },
    { title: "Menu", link: "#menu" },
    { title: "Gallery", link: "#gallery" },
    { title: "Contact", link: "#contact" }
  ],
  buttonText = "Order Now",
  buttonLink = "#contact"
  /* ---------------------------- */
}) {
  return (
    <header className="header">
      <div className="header-container">
        <div className="logo">{logo}</div>

        <nav className="nav">
          {menus.map((menu) => (
            <a key={menu.link} href={menu.link}>
              {menu.title}
            </a>
          ))}
        </nav>

        <a href={buttonLink} className="header-btn">
          {buttonText}
        </a>
      </div>
    </header>
  );
}

export default Header;