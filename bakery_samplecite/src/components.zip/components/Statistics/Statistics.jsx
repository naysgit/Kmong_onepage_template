import {
  FolderOpen,
  Users,
  Award,
  Clock,
} from "lucide-react";

function Statistics({
  badge = "OUR STORY",
title = "매일 신선한 재료로",
subtitle = "좋은 재료와 정성으로 만든 빵을 제공합니다.",

  stats = [
    {
      icon: FolderOpen,
      number: "20+",
      label: "Fresh Bread",
    },
    {
      icon: Users,
      number: "10",
      label: "Years",
    },
    {
      icon: Users,
      number: "5000+",
      label: "Happy Customers",
    },
    {
      icon: Clock,
      number: "100%",
      label: "Fresh Daily",
    },
  ],
}) {

  return (

    <section className="statistics section">

      <div className="container">

        <div className="section-header">

          <span className="section-badge">

            {badge}

          </span>

          <h2 className="section-title">

            {title}

          </h2>

          <p className="section-subtitle">

            {subtitle}

          </p>

        </div>

        <div className="statistics-grid">

          {stats.map((item, index) => {

            const Icon = item.icon;

            return (

              <div
                className="statistics-card"
                key={index}
              >

                <div className="statistics-icon">

                  <Icon size={34} />

                </div>

                <h3>

                  {item.number}

                </h3>

                <p>

                  {item.label}

                </p>

              </div>

            );

          })}

        </div>

      </div>

    </section>

  );

}

export default Statistics;