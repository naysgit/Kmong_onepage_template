function Hero({
badge = "ARTISAN BAKERY",
title = "Fresh Bread Every Morning",
description =
"갓 구운 빵과 따뜻한 커피를 즐길 수 있는 프리미엄 베이커리입니다.",
primaryButton = "View Menu",
secondaryButton = "Visit Us",
image = null,
}) {
  return (
    <section className="hero">

      <div className="hero-container">

        {/* 왼쪽 */}

        <div className="hero-content">

          <span className="hero-badge">
            {badge}
          </span>

          <h1>
            {title}
          </h1>

          <p>
            {description}
          </p>

          <div className="hero-buttons">

            <button className="primary-btn">
              {primaryButton}
            </button>

            <button className="secondary-btn">
              {secondaryButton}
            </button>

          </div>

        </div>

        {/* 오른쪽 */}

        <div className="hero-image">

          <div className="image-card">
                {image && (
                    <img
                    src={image}
                    alt="Hero"/>
                )}
                
          </div>

        </div>

      </div>

    </section>
  );
}

export default Hero;